
1. Document:
Theme’s instruction is in the folder ‘document’. Please open that folder and open the file ‘index.html’ with your browsers.

2. Installable Wordpress Theme File

3. Plugin requires: you can install these plugin by download on Wordpress Plugin directory:
- Envato Wordpress Toolkit
- Woocommerce: https://wordpress.org/plugins/woocommerce/
- Meta Slider: https://wordpress.org/plugins/ml-slider/
- Regenerate-thumbnails: https://wordpress.org/plugins/regenerate-thumbnails/
- MailChimp: https://wordpress.org/plugins/mailchimp-for-wp/
- Contact Form 7: https://wordpress.org/plugins/contact-form-7/
- Loco Translate: https://wordpress.org/plugins/loco-translate/
